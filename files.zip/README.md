# Orbit Watch
1. `python server.py`
2. Open http://localhost:8000  (8k textures by default; add `?lq` for 2k on weak GPUs)

On first run the server downloads and caches, in the background:
- **`textures/`** — planet and sun textures from Solar System Scope, plus moon photos from the Celestia project (a different
  free source, since Solar System Scope doesn't publish moon textures). If a Solar System Scope download fails, drop the file
  in by hand from solarsystemscope.com/textures (names like `2k_mars.jpg`, `2k_saturn_ring_alpha.png`).
- **`models/`** — real 3D models (`.glb`) for the ISS, Hubble, JWST, Juno, the Mars Reconnaissance Orbiter, Voyager, and the
  Perseverance rover, from NASA's 3D Resources repository. Every other spacecraft still uses a simplified stand-in shape, since
  NASA hasn't published a free model for most of them.
- **`/api/sc`** — live spacecraft positions, proxied from NASA JPL Horizons (browsers can't call it directly).

**Deploying to Netlify:** Netlify can't run `server.py`. Run it locally once so `textures/` and `models/` are fully populated,
then commit those two folders alongside `index.html`, `app.js`, and `netlify.toml` — see the Netlify instructions you were
given separately. The `netlify/functions/sc.js` function replaces the live-spacecraft part of the server; the textures and
models are served as plain static files instead.

Credits: planet/sun textures © Solar System Scope (CC BY 4.0); moon textures via the Celestia project (CC BY-NC-SA); 3D models
via NASA 3D Resources (public domain); orbit data via CelesTrak; live spacecraft ephemerides via NASA JPL Horizons.
